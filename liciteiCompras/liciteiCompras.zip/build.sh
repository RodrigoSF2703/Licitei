#!/bin/bash

zip -r "liciteiCompras.zip" * -x "liciteiCompras.zip"